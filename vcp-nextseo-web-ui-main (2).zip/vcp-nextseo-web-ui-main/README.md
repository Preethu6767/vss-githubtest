nginx port (5133)
https://elearning.virtusasystems.com/api/courses/ta/course_group/acsltheory-grp