import { isTesting, subscriberCode } from "../config";
let url = `https://calsvc${isTesting ? "testing" : ""}.virtusasystems.com`;

const getAllSchedules = async (
  subscriberCode,
  type = "null",
  year = "null",
  courseCode = "null",
  eventKey = "null"
) => {
  const res = await fetch(
    `${url}/vcp-cal/api/get-scheduleType-events/${subscriberCode}/web/${courseCode}/shivam/${type}/${year}/${eventKey}`

    // `${url}/vcp-cal/api/getseoevent/${subscriberCode}/web/${courseCode}/rj/${type}/${year}/${eventKey}`
  );
  return res;
};
const genEnrollmentUserApi = (
  subscriberCode,
  courseCode = "null",
  year = "null"
) => {
  return `${url}/vcp-cal/api/enrolled-users/?courseCode=${courseCode}&subscriberCode=${subscriberCode}&userName=rj&year=${year}`;
};
const getSchedulesBySessionTypeApi = async (type, subscriberCode) => {
  const res = await fetch(
    `${url}/vcp-cal/api?sessionType=${type}&subscriberCode=${subscriberCode}`
  );
  return res;
};
export {
  getAllSchedules,
  genEnrollmentUserApi,
  url,
  getSchedulesBySessionTypeApi,
};
