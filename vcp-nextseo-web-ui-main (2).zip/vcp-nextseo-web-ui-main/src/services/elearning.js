import { subscriberCode, isTesting } from "../config";

let url = `https://elearning${
  isTesting ? "testing" : ""
}.virtusasystems.com/api`;
// let url = "http://localhost:5001";

const getMenuApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/menus/${subscriberCode}/${code}`, {
    cache: "no-store",
  });
  return res;
};
const getCourseGroupApi = async (subscriberCode, code) => {
  const res = await fetch(
    `${url}/course_groups/md/${subscriberCode}?sort_by=sequence_order&is_public=1`,
    {
      cache: "no-store",
    }
  );
  return res;
};
const getCourseApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/courses/md/${subscriberCode}/${code}`, {
    cache: "no-store",
  });

  return res;
};
const getCoursePageApi = async (subscriberCode) => {
  const res = await fetch(`${url}/courses/md/${subscriberCode}/course_page`, {
    cache: "no-store",
  });

  return res;
};
const getSliderApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/sliders/${subscriberCode}/${code}`, {
    cache: "no-store",
  });
  return res;
};

const getCourseDetailsApi = async (code) => {
  const res = await fetch(`${url}/course_details/md/${code}`, {
    cache: "no-store",
  });
  return res;
};
const getDashboardDetailsApi = async (subscriberCode, code) => {
  const res = await fetch(
    `${url}/course_toc_details/${subscriberCode}/course_code/${code}`,
    {
      cache: "no-store",
    }
  );
  return res;
};

const getDashboardMenus = async (subscriberCode, code) => {
  const res = await fetch(`${url}/dashboard_menus/${subscriberCode}/${code}`, {
    cache: "no-store",
  });
  return res;
};
const getPageHtmlApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/html_pages/${subscriberCode}/${code}`, {
    cache: "no-store",
  });

  return res;
};
const getBlogsApi = async (subscriberCode) => {
  const res = await fetch(`${url}/blogs/${subscriberCode}`, {
    cache: "no-store",
  });

  return res;
};
const getBlogApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/blogs/${subscriberCode}/${code}`, {
    cache: "no-store",
  });

  return res;
};
const getPagesApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/pages/${subscriberCode}/${code}`, {
    cache: "no-store",
  });

  return res;
};

const getConfigFile = async (subscriberCode, code) => {
  const res = await fetch(`${url}/config_files/${subscriberCode}/${code}`, {
    cache: "no-store",
  });

  return res;
};
const getResultsApi = async (subscriberCode, code) => {
  const res = await fetch(`${url}/results/${subscriberCode}/${code}`, {
    cache: "no-store",
  });

  return res;
};

const getCoursesFromMariadbApi = async (subscriberCode) => {
  const res = await fetch(`${url}/courses/md/${subscriberCode}`);
  return res;
};

const getJobsApi = async (subscriberCode) => {
  const res = await fetch(`${url}/jobs/${subscriberCode}`);
  return res;
};
const getSubscriberCode = (host) => {
  switch (host) {
    case "next.raiseexamscores.in":
      return "RES_IN";
    case "next.raiseexamscores.com":
      return "RES";
    case "next.talentacad.com":
      return "TA";
    case "raiseexamscores.in":
      return "RES_IN";
    case "raiseexamscores.com":
      return "RES";
    case "virtusasystems.com":
      return "VSS";
    case "virtusasystems.in":
      return "VSS_IN";
    case "talentacad.com":
      return "TA";
    case "vilacademy.org":
      return "VIL";
    case "acsl.raiseexamscores.com":
      return "ACSL";
    case "www.raiseexamscores.in":
      return "RES_IN";
    case "www.raiseexamscores.com":
      return "RES";
    case "www.virtusasystems.com":
      return "VSS";
    case "www.virtusasystems.in":
      return "VSS_IN";
    case "www.talentacad.com":
      return "TA";
    case "www.vilacademy.org":
      return "VIL";
    case "www.acsl.raiseexamscores.com":
      return "ACSL";
    case "localhost:3000":
      return subscriberCode;
  }
};

const getLoginUrl = (host) => {
  if (host.startsWith("next.")) {
    return `https://microlms.${host.slice(5)}`; // Remove "next." and prefix with "microlms."
  } else if (host.startsWith("acsl.")) {
    return `https://acslmicrolms.${host.slice(5)}`; // Replace "acsl." with "acslmicrolms."
  } else if (host.startsWith("www.")) {
    return `https://microlms.${host.slice(4)}`; // Remove "www." and prefix with "microlms."
  } else {
    return `https://microlms.${host}`; // Default case: Prefix with "microlms."
  }
};
export {
  getMenuApi,
  getCourseGroupApi,
  getCourseApi,
  getCoursesFromMariadbApi,
  getConfigFile,
  getPageHtmlApi,
  getSubscriberCode,
  getDashboardDetailsApi,
  url,
  getSliderApi,
  getBlogsApi,
  getBlogApi,
  getPagesApi,
  getDashboardMenus,
  getCoursePageApi,
  getResultsApi,
  getJobsApi,
  getLoginUrl,
  getCourseDetailsApi,
};
