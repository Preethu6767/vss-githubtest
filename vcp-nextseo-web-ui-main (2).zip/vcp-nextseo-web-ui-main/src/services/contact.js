import { isTesting } from "../config";
let url = `https://${isTesting ? "testing" : ""}contacts.virtusasystems.com/api`;

const getInstructorsApi = async (subscriberCode) => {
  let api =
    subscriberCode === "RES" || subscriberCode === "RES_IN"
      ? `${url}/instructor/public-data/${subscriberCode}`
      : `${url}/instructor/data?subcode=${subscriberCode}`;

  const res = await fetch(api);
  return res;
};

const userLoginApi = async (data) => {
  const res = await fetch(`${url}/login/verify_jwt`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return res;
};

const getSchoolsApi = async (subscriberCode) => {
  const res = await fetch(
    `${url}/subscriber/public-profile?orgcode=${subscriberCode}`
  );
  return res;
};
export { getInstructorsApi, getSchoolsApi, userLoginApi,url };
