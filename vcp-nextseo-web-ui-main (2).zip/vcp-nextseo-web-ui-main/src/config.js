let subscriberCode = "TA";

let isTesting = false;

export { subscriberCode, isTesting };
