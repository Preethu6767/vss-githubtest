import { useRouter } from "next/navigation";
import React, { useContext, useEffect, useState } from "react";
import Modal from "react-bootstrap/Modal";
import MyContext from "../context/MyContext";
import { getConfigFile } from "../services/elearning";

const EnrollPopup = ({ flag, setFlag, courseName, courseCode }) => {
  const { subscriberCode } = useContext(MyContext);
  const [registerUrl, setRegisterUrl] = useState();
  const [loginUrl, setLoginUrl] = useState();

  const redirectToLMSSite = async (type) => {
    const baseURL = "https://ecommerce-api.virtusasystems.com";
    try {
      const res = await fetch(baseURL + "/auth/login/logs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          subscriber_code: subscriberCode,
          course_code: courseCode,
          created_for: type,
        }),
      })

      let url = type === "register" ? registerUrl : loginUrl;


      console.log(url)
      window.open(`${url}${url.includes('?') ? '&' : '?'}course-code=${courseCode}`, "_blank")

    }
    catch (e) {
      console.log(e?.message)
    }

  };
  useEffect(() => {
    const fetchConfigFile = async () => {
      const res = await getConfigFile(subscriberCode, "site-config");
      const json = await res.json();
      setRegisterUrl(json?.register_url);
      setLoginUrl(json?.login_url);

    };
    fetchConfigFile();
  }, [subscriberCode]);
  return (
    <>
      <Modal
        show={flag}
        onHide={() => {
          setFlag(false);
        }}
        size="lg"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title className=" fs-6  ">
            Enroll in {courseName}&nbsp; ({courseCode})
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row align-items-center">
            <div className="col-6 text-center justify-content-center align-items-center">
              <div className="d-flex flex-column justify-content-center align-items-center">
                <p className="  fs-6">Don't have any account?</p>
                <button
                  className="btn bg-secondary text-white"
                  onClick={() => redirectToLMSSite("register")}
                >
                  Create Account
                </button>
              </div>
            </div>
            <div className="col-6 border-start d-flex justify-content-center">
              <div className="p-3 d-flex flex-column align-items-center">
                <p className="text-center">Already have an account?</p>
                <button
                  className="btn bg-secondary text-white"
                  onClick={() => redirectToLMSSite("login")}
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
};

export default EnrollPopup;
