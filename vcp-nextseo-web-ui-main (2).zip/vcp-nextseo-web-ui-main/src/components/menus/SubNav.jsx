"use client"
import Link from 'next/link'
import { useParams } from 'next/navigation'
import React from 'react'

const SubNav = () => {
    const params = useParams();

    return (
        <div className="d-flex gap-1">
            <Link
                href={`/courses/${params.course_code}`}
                className="p-2 px-3 fs-6 text-white bg-secondary text-decoration-none"
            >
                Course TOC
            </Link>
            <Link
                href={`/courses/${params.course_code}/desc`}
                className="p-2 px-3 fs-6 text-white bg-secondary text-decoration-none"
            >
                Course Description
            </Link>
            <Link
                href={`/courses/${params.course_code}/slider`}
                className="p-2 px-3 fs-6 text-white bg-secondary text-decoration-none"
            >
                Course Slider
            </Link>
        </div>
    )
}

export default SubNav