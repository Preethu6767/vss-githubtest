"use client"
import { useParams } from "next/navigation";
import Link from "next/link";
import { useRouter } from "next/navigation";

import { FaPlus } from "react-icons/fa";


const CourseGroupMenu = ({ menus }) => {
    const params = useParams();
    const router = useRouter();
    return (
        <>
            <ul className="shadow-sm navbar-nav leftmenu accordion">
                {menus?.map((menu, index) => (

                    <>
                        <li
                            className={`accordion-item nav-item border`}
                            onClick={() => {
                                router.push(menu.link)
                            }}

                        >
                            <div className={`p-2 d-flex align-items-center justify-content-between shadow-none ${(`/cl/${params.course_group_code}` === menu.link && !params.course_code) ? "bg-primary text-white" : "bg-white text-black"}`} style={{ cursor: "pointer" }}>
                                {menu.text}

                                {
                                    menu.sub_menus?.length > 0 &&

                                    <button
                                        className={`btn p-0 me-1 btn-sm`}
                                        type="button"
                                        data-bs-toggle="collapse"
                                        data-bs-target={`#${menu.text.split(" ").join("")}`}
                                        onClick={(e) => { e.stopPropagation() }}
                                    >

                                        <FaPlus />

                                    </button>
                                }
                            </div>




                        </li>
                        <div
                            id={menu.text.split(" ").join("")}
                            className="accordion-collapse  collapse "

                            style={{}}
                        >
                            <div className="accordion-body p-0">
                                <ul className="p-0">

                                    {
                                        menu.sub_menus?.map((sub_menu) => (
                                            <li className="my-1">
                                                <Link style={{ whiteSpace: "normal" }} className={`dropdown-item    p-2 ${`/cl/${params.course_group_code}/courses/${params.course_code}` === sub_menu.link ? "bg-primary text-white" : "bg-white text-black"}`} href={sub_menu.link}>
                                                    {sub_menu.text}
                                                </Link>
                                            </li>
                                        ))
                                    }
                                </ul>
                            </div>
                        </div>
                    </>

                ))}
            </ul>
        </>
    )
}

export default CourseGroupMenu