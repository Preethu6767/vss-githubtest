"use client"
import React, { useRef } from "react";
import Link from "next/link";
import { MdLogin } from "react-icons/md";
import { MdEmail } from "react-icons/md";
import { FaPhoneAlt } from "react-icons/fa";
import { usePathname, useRouter } from 'next/navigation'
import { FaFacebook } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";
const Topmenu = ({ header }) => {
    const navbarRef = useRef(null);
    const router = useRouter();
    const pathname = usePathname();
    const clickHandler = (e, a) => {
        e.preventDefault();
        if (a.redirect) {
            window.open(a.link, "_blank");
            return;
        }
        handleToggle();
        router.push(`${a.link}`);
    };
    const handleToggle = () => {
        const collapseElement = navbarRef.current;
        if (collapseElement.classList.contains('show')) {
            collapseElement.classList.remove('show')
        }
    };

    return (
        <>
            {header && (
                <header
                    className={"top-header topmenu p-1 px-3  sticky-top bg-primary  shadow-sm text-black "}
                    style={{ fontSize: "14px", }}
                >
                    <nav className="navbar navbar-expand-lg ">
                        <div className="container-fluid   ">
                            <Link
                                className="navbar-brand d-flex me-3  flex-row align-items-center"
                                href="/"
                            >
                                {header?.logo?.display !== "none" && (
                                    <img
                                        className="img-fluid me-2 company-logo"
                                        alt=""
                                        src={header?.logo?.img}
                                        style={{
                                            width: "50px",
                                            height: "50px",
                                        }}
                                    />
                                )}
                                <h1 className=" fs-4 ms-2 fw-semibold text-white" >
                                    {header.brand}
                                </h1>
                            </Link>
                            <button
                                className="navbar-toggler"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#topMenu"
                                aria-controls="topMenu"
                                aria-expanded="false"
                                aria-label="Toggle navigation"
                            >
                                <span className="navbar-toggler-icon"></span>
                            </button>

                            <div id="topMenu" ref={navbarRef} className="collapse navbar-collapse  ">
                                <ul className="navbar-nav mb-2 mb-lg-0 ms-auto align-items-center">
                                    {header.links?.map((link) => {
                                        if (link.sub_menus && link.sub_menus.length > 0) {
                                            return (
                                                <li
                                                    className="nav-item dropdown "
                                                    key={link.name}
                                                >
                                                    <button
                                                        className="nav-link text-white dropdown-toggle"
                                                        role="button"
                                                        data-bs-toggle="dropdown"
                                                        aria-expanded="false"
                                                        style={{
                                                            backgroundColor: "transparent",
                                                        }}
                                                    >
                                                        {link.name}
                                                    </button>
                                                    <ul className="dropdown-menu">
                                                        {link.sub_menus.map((item) => (
                                                            <li key={item.name} >
                                                                <button
                                                                    href={`.${item.link}`}
                                                                    onClick={(e) => {
                                                                        clickHandler(e, item);
                                                                    }}
                                                                    className="dropdown-item"
                                                                >
                                                                    {item.name}
                                                                </button>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </li>
                                            );
                                        } else {
                                            return (
                                                <li className="nav-item " key={link.name}>
                                                    <button
                                                        className={`text-white nav-link ${pathname === link.link ? "active border-2 text-black border-bottom border-primary" : ""}`}

                                                        href={`.${link.link}`}
                                                        onClick={(e) => {
                                                            clickHandler(e, link);

                                                        }}
                                                    >
                                                        {link.name}
                                                    </button>
                                                </li>
                                            );
                                        }
                                    })}

                                    <li className="mx-3"></li>

                                    {header.email && (
                                        <li className="nav-item">
                                            <button
                                                className="nav-link text-white"

                                                href={`.${header.email.link}`}
                                                onClick={(e) => {
                                                    clickHandler(e, header.email);
                                                }}
                                            >
                                                <MdEmail /> &nbsp;
                                                {header.email.name}
                                            </button>
                                        </li>
                                    )}

                                    {header.phone && (
                                        <li className="nav-item ">
                                            <button
                                                className="nav-link text-white"

                                                href={`.${header.phone.link}`}
                                                onClick={(e) => {
                                                    clickHandler(e, header.phone);
                                                }}
                                            >
                                                <FaPhoneAlt />{" "}
                                                {header.phone.name}
                                            </button>
                                        </li>
                                    )}

                                    <>
                                        {header.buttons &&
                                            header.buttons.map((button) => (
                                                <li className="button mx-1 " key={button.name}>
                                                    <button
                                                        className="nav-link text-white rounded-2 bg-primary "
                                                        style={{ fontSize: "13px" }}
                                                        href={`.${button.link}`}
                                                        onClick={(e) => {
                                                            clickHandler(e, button);
                                                        }}
                                                    >
                                                        <MdLogin /> {button.name}
                                                    </button>
                                                </li>
                                            ))}
                                    </>
                                    {header.facebook && (
                                        <li className="nav-item me-1 fs-5">
                                            <Link
                                                className="nav-link text-white"
                                                href={header.facebook}
                                                target="_blank"

                                            >
                                                <FaFacebook />{" "}

                                            </Link>
                                        </li>
                                    )}
                                    {header.twitter && (
                                        <li className="nav-item me-1 fs-5">
                                            <Link
                                                className="nav-link text-white"
                                                href={header.twitter}
                                                target="_blank"

                                            >
                                                <FaTwitter />{" "}

                                            </Link>
                                        </li>
                                    )}
                                    {header.linkedin && (
                                        <li className="nav-item me-1 fs-5">
                                            <Link
                                                className="nav-link text-white"
                                                href={header.linkedin}
                                                target="_blank"

                                            >
                                                <FaLinkedin />

                                            </Link>
                                        </li>
                                    )}
                                </ul>


                            </div>
                        </div>
                    </nav>

                </header>
            )}

        </>
    );

};

export default Topmenu;

