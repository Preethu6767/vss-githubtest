"use client"
import React, { useContext, useEffect } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { FaPlus } from "react-icons/fa";
import MyContext from "../../context/MyContext";


const Leftmenu = ({ leftMenuData, courseGroupsData, type }) => {
    const { setCourseGroups } = useContext(MyContext)
    const params = useParams();
    const router = useRouter();
    useEffect(() => {
        setCourseGroups(courseGroupsData)
    }, [courseGroupsData])

    const displayCourseGroupLink = (courseGroup) => {

        const courseGroupClassName = params.course_group_code === courseGroup?.course_group_code ? "bg-primary text-white" : "bg-white text-black"

        return (
            <>
                <li
                    className={`accordion-item nav-item border`}
                >
                    <div
                        className={`p-2 nav-link d-flex align-items-center justify-content-between shadow-none ${courseGroupClassName}`}
                        style={{ cursor: "pointer" }}

                        onClick={() => {

                            router.push(`/cg/${courseGroup?.course_group_code}`)

                        }}
                    >
                        {courseGroup?.name}
                        {courseGroup?.courses?.length > 0 && (
                            <button
                                className={`btn p-0 me-1 btn-sm ${courseGroupClassName}`}
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target={`#${courseGroup?.name.split(" ").join("")}`}
                                onClick={(e) => {
                                    e.stopPropagation();
                                }}
                            >
                                <FaPlus />
                            </button>
                        )}
                    </div>

                </li>
                <div
                    id={`${courseGroup?.name.split(" ").join("")}`}
                    className="accordion-collapse  collapse "
                >
                    <div className="accordion-body p-0">
                        <ul className="p-0">
                            {
                                courseGroup?.courses?.map((course) => {
                                    const courseClassName = params.course_group_code + params.course_code
                                        === courseGroup?.course_group_code + course?.course_code
                                        ? "bg-primary text-white" : "bg-white text-black"
                                    return (

                                        <li className="my-1">
                                            <Link style={{ whiteSpace: "normal" }} className={`dropdown-item text-black  p-2 ${courseClassName}`} href={`/courses/${course?.course_code}`}>
                                                {course.name}
                                            </Link>
                                        </li>
                                    )
                                }
                                )
                            }
                        </ul>
                    </div>
                </div >
            </>
        )
    }

    return (

        <>
            <nav className="fs-6 side-navigation ">
                <ul id="sideMenu " className="shadow-sm navbar-nav leftmenu accordion">

                    {courseGroupsData?.map((courseGroup) => {
                        return (
                            displayCourseGroupLink(courseGroup)
                        );
                    })}
                    {leftMenuData?.menus?.map((item) => {
                        return (
                            <li
                                key={item.text}
                                className={`accordion-item nav-item border`}
                            >

                                <Link
                                    className={`p-2 nav-link `}
                                    style={{ cursor: "pointer" }}
                                    href={item?.link}
                                >
                                    {item.text}
                                </Link>
                            </li>
                        );

                    })}

                </ul>
            </nav>


        </>

    );
};

export default Leftmenu;
