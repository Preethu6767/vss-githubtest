"use client"

import moment from 'moment'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useRouter } from 'next/navigation'
import React, { useContext, useEffect, useState } from 'react'
import MyContext from '../../context/MyContext'

const filters = [
    {
        key: "2022-2023",
        value: 2022,
    },
    {
        key: "2023-2024",
        value: 2023,
    },
    {
        key: "2024-2025",
        value: 2024,
    }
]
const SchedulesMenu = ({ courseFlag = false }) => {
    const router = useRouter();
    const params = useParams();
    const { subscriberCode } = useContext(MyContext)
    const [year, setYear] = useState(moment().format("YYYY"))

    useEffect(() => {
        if (params.year) {
            setYear(params.year);
        }

    }, [])

    return (
        <>
            <div className="d-flex gap-1">
                {
                    subscriberCode !=="VIL" &&
                <select className="form-select"
                    value={year}
                    onChange={
                        (e) => {
                            router.push(`/schedules/${courseFlag ? `course/${params.course_code}` : ""}/${e.target.value}`)
                        }
                    }
                    style={{ width: "200px" }} aria-label="Default select example">
                    {
                        filters.map((item) => (
                            <option key={item.key}

                                value={item.value}>{item.key}</option>

                        ))
                    }
                </select>
                }
                {
                    subscriberCode === "TA" &&
                    <Link
                        href={`/schedules/${courseFlag ? `course/${params.course_code}` : ""}/enrolled-users`}
                        className="p-2 px-3 fs-6 text-white bg-primary text-decoration-none"
                    >
                        Enrolled Users
                    </Link>
                }
            </div>
        </>
    )




}

export default SchedulesMenu
