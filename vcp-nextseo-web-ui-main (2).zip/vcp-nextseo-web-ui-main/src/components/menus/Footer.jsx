import React from "react";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FaTwitterSquare } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { FaPhoneAlt } from "react-icons/fa";

const Footer = ({ footerData }) => {
  const router = useRouter();
  const clickHandler = (e, a) => {
    e.preventDefault();
    if (a.redirect) {
      window.open(a.link, "_blank");
      return;
    }
    router.push(`${a.link}`);
  };

  return (
    <>
      {footerData ? (
        <div
          className="footer container-fluid bg-primary  footer "

        >
          {footerData.primaryLinks && (
            <div className="footer-nav py-3 flex-wrap d-flex">
              {footerData.primaryLinks.map((item, index) => (
                <div className="f-item" key={index}>
                  <ul>
                    <li className="nav-title text-white">{item.name}</li>
                    {item.links.map((link, index) => (
                      <li key={index}>
                        <button
                          className="list-group-item text-white footer-link"
                          href={`${link.link}`}
                          onClick={(e) => {
                            clickHandler(e, link);
                          }}
                        >
                          {link.text}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              {footerData.contactUs && (
                <div className="f-item">
                  <ul>
                    <li className="nav-title text-white">{footerData.contactUs.name}</li>

                    {footerData.contactUs.email && (
                      <li>
                        <button
                          href={`.${footerData.contactUs.email.link}`}
                          className="list-group-item footer-link d-flex gap-2 text-white"
                          onClick={(e) => {
                            clickHandler(e, footerData.contactUs.email);
                          }}
                        >
                          <span className="me-1">

                            <MdEmail />
                          </span>
                          {footerData.contactUs.email.text}
                        </button>
                      </li>
                    )}
                    {footerData.contactUs.phone && (
                      <li>
                        <button
                          href={`.${footerData.contactUs.phone.link}`}
                          className="list-group-item text-white"
                          onClick={(e) => {
                            clickHandler(e, footerData.contactUs.phone);
                          }}
                        >
                          <span className="me-1">

                            <FaPhoneAlt />
                          </span>
                          {footerData.contactUs.phone.text}
                        </button>
                      </li>
                    )}


                    <li className="social-media d-flex gap-2">
                      {footerData.contactUs.facebook && (
                        <button
                          className="list-group-item text-white fs-3"
                          href={`.${footerData.contactUs.facebook.link}`}
                          onClick={(e) => {
                            clickHandler(e, footerData.contactUs.facebook);
                          }}
                        >
                          <FaFacebook />
                        </button>
                      )}
                      {footerData.contactUs.twitter && (
                        <button
                          href={footerData.contactUs.twitter.link}
                          className="list-group-item text-white fs-3"
                          onClick={(e) => {
                            clickHandler(e, footerData.contactUs.twitter);
                          }}

                        >
                          <FaTwitterSquare />
                        </button>
                      )}
                    </li>

                  </ul>
                </div>
              )}
            </div>
          )}
          <div className="row footer-bottom p-2 ">
            {footerData.image && (
              <div className="col-md-3">
                <img
                  className="img-fluid"
                  src={footerData.image.url}
                  alt={footerData.image.alt}
                  style={{
                    width: footerData.image.width,
                    height: footerData.image.height,
                  }}
                />
              </div>
            )}
            {footerData.copyright && (
              <div className="col-md-12 policy-terms text-center text-white">
                <span>{footerData.copyright.text}</span>

                {footerData.copyright.links &&
                  footerData.copyright.links.map((link, index) => (
                    <Link href={`.${link.link}`} onClick={(e) => { clickHandler(e, link) }} key={index}>
                      {link.text}
                    </Link>
                  ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div></div>
      )}
    </>
  );
};

export default Footer;
