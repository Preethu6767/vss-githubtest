"use client";
import React, { useContext } from "react";
import { Auth } from "vcp-ecommerce-components";
import MyContext from "../../context/MyContext";
import { useRouter } from "next/navigation";

const AuthComponent = () => {
  const router = useRouter();
  const OnRedirectToLink = () => {
    router.push("/ecommerce-demo/courses");
  };
  const { subscriberCode } = useContext(MyContext);
  return (
    <Auth subscriberCode={subscriberCode} OnRedirectToLink={OnRedirectToLink} />
  );
};

export default AuthComponent;
