"use client";
import React, { useContext } from "react";
import { Courses } from "vcp-ecommerce-components";
import MyContext from "../../context/MyContext";
import { useRouter } from "next/navigation";

const CoursesComponent = () => {
  const { subscriberCode } = useContext(MyContext);
  const router = useRouter();
  const OnRedirectToLink = () => {
    router.push("/ecommerce-demo/cart");
  };
  return (
    <Courses
      subscriberCode={subscriberCode}
      OnRedirectToLink={OnRedirectToLink}
    />
  );
};

export default CoursesComponent;
