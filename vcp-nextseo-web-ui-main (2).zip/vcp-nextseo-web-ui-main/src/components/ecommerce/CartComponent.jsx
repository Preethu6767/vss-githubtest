"use client";
import React, { useContext } from "react";
import { Cart } from "vcp-ecommerce-components";
import MyContext from "../../context/MyContext";
import { useRouter } from "next/navigation";

const CartComponent = () => {
  const { subscriberCode } = useContext(MyContext);
  const router = useRouter();
  const OnRedirectToLink = () => {
    router.push("/ecommerce-demo/checkout");
  };
  return (
    <Cart subscriberCode={subscriberCode} OnRedirectToLink={OnRedirectToLink} />
  );
};

export default CartComponent;
