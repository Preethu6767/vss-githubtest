"use client";
import React, { useContext } from "react";
import { Checkout } from "vcp-ecommerce-components";
import MyContext from "../../context/MyContext";
import { useRouter } from "next/navigation";

const CheckoutComponent = () => {
  const { subscriberCode } = useContext(MyContext);
  const router = useRouter();
  const OnRedirectToLink = () => {
    router.push("/ecommerce-demo/courses");
  };
  return (
    <Checkout subscriberCode={subscriberCode} OnRedirectToLink={OnRedirectToLink} />
  );
};

export default CheckoutComponent;
