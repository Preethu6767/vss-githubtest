"use client"
import React, { useContext, useEffect, useState } from "react";
import Link from "next/link";
import { FaPencilAlt } from "react-icons/fa";
import { FaBook } from "react-icons/fa";
import { MdEvent } from "react-icons/md";
import EnrollPopup from "./EnrollPopup";
import MyContext from "../context/MyContext";
import moment from "moment";

const CourseGroup = ({ courseGroupCode }) => {

    const { subscriberCode, courseGroups } = useContext(MyContext);
    const [selectedCourse, setSelectedCourse] = useState(null);
    const { setBufferCourseCode } = useContext(MyContext)
    const [enrollFlag, setEnrollFlag] = useState(false);
    const [selectedCourseGroup, setSelectedCourseGroup] = useState(null);

    useEffect(() => {
        console.log(courseGroupCode, "courseGroupCode")
        console.log(courseGroups, "courseGroups")
        if (courseGroups?.length) {
            let cg = courseGroups?.find((item) => item.course_group_code === courseGroupCode)
            setSelectedCourseGroup(cg);
            console.log(cg, "cg")
        }
    }, [courseGroupCode, courseGroups])

    return (
        <div className="">
            {selectedCourseGroup && (
                <>
                    <h1 className="text-dark fw-normal fs-3 m-2 " >
                        {selectedCourseGroup && selectedCourseGroup?.name}
                    </h1>
                    <div className="">
                        <div className="row ">
                            {selectedCourseGroup?.courses?.map((course, index) => (

                                <div className="col-md-6 my-3" key={index}>
                                    <div className="shadow-sm rounded ">

                                        <h2 className=" p-2 px-3 bg-secondary fw-semibold text-white" style={{ fontSize: "15px" }}>{course.name} </h2>

                                        <div className="text-gray p-2 px-3 " style={{ fontSize: "15px" }}>
                                            {course.short_description}
                                        </div>

                                        <div className=" p-2  border-top text-black" >
                                            <Link
                                                href="/student-ui"
                                                className="p-2 text-gray   text-decoration-none  "
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    setSelectedCourse(course);
                                                    setEnrollFlag(true)
                                                    setBufferCourseCode(course?.course_code)

                                                }}
                                            >
                                                <span className="me-2">
                                                    <FaPencilAlt />
                                                </span>
                                                Enroll
                                            </Link>

                                            <Link href={`/courses/${course?.course_code}`}
                                                className="p-2 text-gray  text-decoration-none  "


                                            >
                                                <span className="me-2">

                                                    <FaBook />
                                                </span>
                                                Course Details
                                            </Link>

                                            {
                                                subscriberCode !== "ACSL" &&
                                                <Link href={`/schedules/course/${course?.course_code}/${moment().format("YYYY")}`}
                                                    className="p-2 text-gray  text-decoration-none  "


                                                >
                                                    <span className="me-2">

                                                        <MdEvent />
                                                    </span>
                                                    Schedule
                                                </Link>
                                            }
                                        </div>
                                    </div>
                                </div>

                            ))}
                        </div>
                    </div>
                </>
            )
            }
            <EnrollPopup flag={enrollFlag} setFlag={setEnrollFlag} courseCode={selectedCourse?.course_code} courseName={selectedCourse?.name} />
        </div>

    );
};

export default CourseGroup;

