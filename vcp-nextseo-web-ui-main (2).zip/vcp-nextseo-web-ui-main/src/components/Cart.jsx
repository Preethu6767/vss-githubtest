"use client"
import React from "react";
import { isTesting } from "../config";

const Cart = ({subscriberCode,courseCode}) => {
  return (
    <>
      <iframe
        className="p-3 mt-3"
        src={`https://ecommerce${
          isTesting ? "-test" : ""
        }.virtusasystems.com/?subscriberCode=${subscriberCode}&courseCode=${courseCode}`}
        title="cart"
        frameborder="0"
        style={{ height: "100vh", width: "-webkit-fill-available" }}
      ></iframe>
    </>
  );
};

export default Cart