import React from "react";

const Problemset = ({ Theme, FontColor }) => {
  const data = [
    {
      id: 1,
      name: "APCS Concepts",
      keywords: "Primitive Types Quiz, Array, ArrayList, 2D Array",
      difficulty: 2500,
      link:"https://talentacad.com/courses/apcs",
      no_of_participants: 2,
    },
    {
        id: 2,
        name: "Number Theory",
        keywords: "Factors, Prime Numbers, LCM And GCF	",
        difficulty: 2500,
        no_of_participants: 3,
        link:"https://talentacad.com/courses/ta-number-theory"
      },
  ];
  return (
    <>
      <div className="container border table-div bg-white rounded mt-5" >
        {data && (
          <table className="table">
            <thead >
              <tr className="text-center" >
                <th scope="col">#</th>
                <th scope="col">Names</th>
                <th scope="col" className="text-warning">
                  <i className="fa-solid fa-wrench"></i>
                </th>
                <th scope="col" className="text-primary">
                  <i className="fa-solid fa-users"></i>
                </th>
              </tr>
            </thead>
            <tbody>
              {data.map((item,index) => (
                <tr className="text-center">
                  <th scope="row">{index+1}</th>
                  <td  className="d-flex justify-content-between">
                    <div><a href={item.link} target="_blank"  rel="noreferrer" >{item.name}</a></div>
                    <div className="text-secondary" style={{fontSize:"13px"}}>{item.keywords}</div>
                  </td>
                  <td>{item.difficulty}</td>
                  <td><i className="fa-solid fa-user"></i> x{item.no_of_participants}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
};

export default Problemset;