"use client"
import Topmenu from './menus/Topmenu';
import { useContext, useEffect, useState } from 'react';
import Leftmenu from './menus/Leftmenu';
import MyContext from '../context/MyContext';
import Footer from './menus/Footer';
import News from './ui/News';
import CourseGroupMenu from './menus/CourseGroupMenu';
import Loader from './common/Loader/Loader';


const Wrapper = ({ courseGroupsData, configData, topMenuData, leftMenuData, children, footerData, newsData }) => {
    const { subscriberCode } = useContext(MyContext)
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        setTimeout(() => {
            setLoading(false);
        }, 1000)
    }, [])

    if (loading) return <Loader />
    return (
        <>

            <Topmenu header={topMenuData} />
            <div className="mb-2"><News news={newsData} type={"alert"} /></div>
            <div style={{ minHeight: "90vh" }}>
                <div className="container-fluid my-4">
                    {
                        (subscriberCode === "TA" || (subscriberCode !== "ACSL" && subscriberCode !== "VIL")) &&
                        <div className="row">
                            <div className="col-md-2">
                                {
                                    configData?.logo &&
                                    <div className='w-100'><img className="img-fluid img mb-4 " src={configData?.logo} alt="" /></div>
                                }
                                <Leftmenu leftMenuData={leftMenuData} courseGroupsData={courseGroupsData} />
                            </div>
                            <div className='col-md-10  position-relative'>
                                {children}
                            </div>
                        </div>

                    }
                    {
                        (subscriberCode === "ACSL" || subscriberCode === "VIL") &&
                        <div className='row'>
                            <div className="col-md-3">
                                {/* <CourseGroupMenu menus={leftMenuData?.menus} /> */}
                                <Leftmenu leftMenuData={leftMenuData} courseGroupsData={courseGroupsData} />
                            </div>
                            <div className='col-md-9  position-relative'>
                                {children}
                            </div>
                        </div>

                    }



                </div>
            </div>
            <Footer footerData={footerData} />
        </>
    )
}

export default Wrapper