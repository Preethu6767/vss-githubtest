"use client"
import React from 'react'
import MyContext from '../context/MyContext';
import { useContext, useEffect } from 'react';
const CssWrapper = ({ children }) => {
    const { subscriberCode } = useContext(MyContext)

    useEffect(() => {
        if (!subscriberCode) return;
        import(`../styles/${subscriberCode}.scss`);
    }, [subscriberCode]);
    return (
        <>
            {children}
        </>
    )
}

export default CssWrapper