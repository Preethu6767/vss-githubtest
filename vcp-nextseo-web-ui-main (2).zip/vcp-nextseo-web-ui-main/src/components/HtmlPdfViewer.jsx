"use client"
import React, { useEffect, useState } from 'react'

const HtmlPdfViewer = () => {
    const [ url, setUrl ] = useState(null);
    useEffect(() => {
        setUrl(localStorage.getItem("pdf_url"))
    }, [])
    return (
        <div className='pdf-viewer'>
            <div className="watermark">

            </div>
            <iframe src={url} className='html-iframe' title="article" />
        </div>
    )

}

export default HtmlPdfViewer