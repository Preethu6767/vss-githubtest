"use client"
import Link from 'next/link'
import React from 'react'

const BlogList = ({ blogs }) => {
    return (
        <div className="row p-2">
            {

                blogs?.map((blog) => {
                    if (blog.status === "published") {
                        return (
                            <div className="col-12 mb-2 border rounded p-4" style={{ cursor: "pointer" }} onClick={() => {  }}>
                                <h3 className="fs-4">{blog.title}</h3>
                                <p className="mb-1">Post at 09-06-2021 06:19:14</p>
                                <p className="my-0 fw-semibold">{blog.seo_description}</p>
                                <p className="my-1">1039 Views</p>
                                <Link className="btn text-white bg-secondary" href={`/blogs/${blog.code}`} >Read Blog</Link>
                            </div>
                        )
                    } else {
                        return (
                            <></>
                        )
                    }
                })
            }
        </div>
    )
}

export default BlogList