"use client"
import { useRouter } from 'next/navigation'
import React from 'react'

import { VcpNews } from 'vcp-ui-components'
const News = ({ news, type }) => {
  const router = useRouter();
  const onClickLink = (link) => {
    if (!link.url) return;
    if (link.redirect) {
      window.open(link.url, "_blank")
    }

    router.push(link.url)

  }
  return (
    <>
      {
        news?.is_active &&
        <VcpNews news={news} type={type} onClickLink={onClickLink} />
      }

    </>
  )
}

export default News