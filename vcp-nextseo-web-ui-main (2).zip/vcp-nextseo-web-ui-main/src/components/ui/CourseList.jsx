"use client"
import React from 'react'
import { VcpCourseList } from 'vcp-ui-components'

const CourseList = ({data}) => {
    return (
        <>
            <VcpCourseList data={data}/>
        </>

    )
}

export default CourseList