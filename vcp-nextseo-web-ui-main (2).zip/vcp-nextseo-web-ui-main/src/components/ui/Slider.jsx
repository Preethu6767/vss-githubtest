"use client"
import React from 'react'
import { VcpCourseSlider } from 'vcp-ui-components'

const Slider = ({sliderData}) => {
  return (
    <VcpCourseSlider sliderData={sliderData} />

  )
}

export default Slider