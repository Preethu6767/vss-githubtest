"use client"
import React, { useContext } from 'react'
import { PdfExplorerDashboard } from 'vcp-ui-components'
import { url } from '../../services/elearning';
import MyContext from '../../context/MyContext';
const PDFDashboard = ({ dashboardCode }) => {
    const { subscriberCode } = useContext(MyContext);
    return (
        <PdfExplorerDashboard
            subscriberCode={subscriberCode} role="admin" elearningUrl={url} dashboardOnlyFlag={true} dashboardCode={dashboardCode}
        />
    )
}

export default PDFDashboard