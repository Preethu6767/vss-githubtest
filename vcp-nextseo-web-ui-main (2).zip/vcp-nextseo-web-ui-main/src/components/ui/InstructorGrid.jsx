"use client"
import React from 'react'
import { VcpInstructorGrid } from 'vcp-ui-components'
const InstructorGrid = ({ instructors }) => {
    return (
        <div className='mb-3'>
            <VcpInstructorGrid instructors={instructors}  />
        </div>
    )
}

export default InstructorGrid