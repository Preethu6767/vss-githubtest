"use client"
import React from 'react'
import { VcpResults } from 'vcp-ui-components'

const Result = ({ data }) => {
    return (
        <VcpResults resultsData={data?.content} />
    )
}

export default Result