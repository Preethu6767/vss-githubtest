"use client"
import React from 'react'
import { CourseDetailsDashboard } from "vcp-ui-components"
const CourseDetailsDashboardUI = ({ data }) => {
    return (
        <CourseDetailsDashboard data={data} ixl={true} />

    )
}

export default CourseDetailsDashboardUI