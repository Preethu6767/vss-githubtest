"use client"
import React from 'react'
import { HolidaysList } from 'vcp-ui-components'

const HolidaysUI = ({ data }) => {
    return (
        <HolidaysList data={data} />
    )
}

export default HolidaysUI