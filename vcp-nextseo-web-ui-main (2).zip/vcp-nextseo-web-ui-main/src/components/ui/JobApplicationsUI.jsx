"use client"
import React, { useState } from 'react'
import { JobApplications } from 'vcp-ui-components'
import EnrollPopup from '../EnrollPopup';

const JobApplicationsUI = ({ data }) => {
    const [job, setJob] = useState(null);
    const [enrollFlag, setEnrollFlag] = useState(false);
    return (
        <div className='container'>

            <JobApplications
                data={data}
                onClickEnrollBtn={(item) => { setJob(item); setEnrollFlag(true) }}
            />
            <EnrollPopup
                flag={enrollFlag}
                setFlag={setEnrollFlag}
                courseCode={job?.course_code}
                courseName={job?.course_name} />
        </div>
    )
}

export default JobApplicationsUI