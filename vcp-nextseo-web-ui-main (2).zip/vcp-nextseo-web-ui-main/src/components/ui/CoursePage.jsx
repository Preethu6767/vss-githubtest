"use client"
import React, { useContext, useState } from 'react'
import { VcpCoursePage } from 'vcp-ui-components'
import MyContext from '../../context/MyContext'
import EnrollPopup from '../EnrollPopup'

const CoursePage = ({ data }) => {
  const { subscriberCode } = useContext(MyContext);
  const [enrollFlag, setEnrollFlag] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const onClickEnrollBtn = (course) => {
    setSelectedCourse(course); setEnrollFlag(true)
  }
  return (
    <>
      <VcpCoursePage
        subscriberCode={subscriberCode}
        onClickEnrollBtn={
          onClickEnrollBtn
        }
        data={data}

      />
      <EnrollPopup
        flag={enrollFlag}
        setFlag={setEnrollFlag}
        courseCode={selectedCourse?.course_code}
        courseName={selectedCourse?.name} />

    </>
  )
}

export default CoursePage