"use client"
import { useRouter } from 'next/navigation'
import React from 'react'
import { VcpDashboardDetails } from 'vcp-ui-components'
const DashboardDetails = ({ dashboards }) => {
  const router = useRouter();
  const onClickPdfLink = (link) => {
    localStorage.setItem("pdf_url", link)
    router.push("/pdfviewer")
  }
  return (
    <VcpDashboardDetails dashboards={dashboards} onClickPdfLink={onClickPdfLink} tabsFlag={true} ixl={true} />
  )
}

export default DashboardDetails