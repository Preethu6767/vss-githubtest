"use client"
import React from 'react'
import { InstructorsUI } from 'vcp-ui-components'

const InstructorsList = ({ instructors }) => {
    return (
        <InstructorsUI data={instructors} />
    )
}

export default InstructorsList