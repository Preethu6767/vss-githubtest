"use client"
import { useRouter } from 'next/navigation'
import React, { useContext } from 'react'
import { url } from '../../services/elearning'
import { VcpDashboardDetailsV2 } from 'vcp-ui-components'
import MyContext from '../../context/MyContext'
const DashboardDetailsV2 = ({ menus }) => {
    const {subscriberCode}=useContext(MyContext);
    const router = useRouter();
    const onClickPdfLink = (link) => {
        localStorage.setItem("pdf_url", link)
        router.push("/pdfviewer")
    }
    return (
        <VcpDashboardDetailsV2 menus={menus} subscriberCode={subscriberCode}url={url} onClickPdfLink={onClickPdfLink}  ixl={true} />
    )
}

export default DashboardDetailsV2