"use client"
import {VcpSchoolGrid} from "vcp-ui-components"
const SchoolsGrid = ({schools, loginUrl}) => {
  return (
    <div><VcpSchoolGrid schools={schools} loginUrl={loginUrl} /></div>
  )
}

export default SchoolsGrid