"use client"
import React, { useContext } from 'react'
import { VcpCourseGroupFlyer } from 'vcp-ui-components'
import MyContext from '../../context/MyContext'
import { url } from '../../services/elearning'
const CourseGroupFlyer = () => {
    const {subscriberCode}=useContext(MyContext);
  return (
    

   <VcpCourseGroupFlyer subscriberCode={subscriberCode} elearningUrl={url}/>
  )
}

export default CourseGroupFlyer