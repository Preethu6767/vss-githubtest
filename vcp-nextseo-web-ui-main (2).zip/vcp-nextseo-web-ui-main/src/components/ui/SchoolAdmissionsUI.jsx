"use client"
import React, { useContext } from 'react'
import { SchoolAdmissions } from 'vcp-calendar-components'
import { url as calendarUrl } from "../../services/calendar"
import { url as contactUrl } from "../../services/contact"
import MyContext from '../../context/MyContext'
const SchoolAdmissionsUI = () => {
    const { subscriberCode } = useContext(MyContext)
    return (
        <SchoolAdmissions
            calendarUrl={calendarUrl}
            contactUrl={contactUrl}
            subscriberCode={subscriberCode}
        />
    )
}

export default SchoolAdmissionsUI