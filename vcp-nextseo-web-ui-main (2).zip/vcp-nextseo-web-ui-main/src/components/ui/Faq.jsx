"use client"
import React from 'react'
import { VcpFaq } from 'vcp-ui-components'

const Faq = ({faqData}) => {
    return (
        <VcpFaq faqData={faqData}/>
    )
}

export default Faq