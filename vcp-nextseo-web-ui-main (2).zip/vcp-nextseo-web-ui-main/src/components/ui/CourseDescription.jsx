"use client"
import React from 'react'
import { VcpCourseDescription } from 'vcp-ui-components'
const CourseDescription = ({course}) => {
  return (
    <VcpCourseDescription course={course} />

  )
}

export default CourseDescription