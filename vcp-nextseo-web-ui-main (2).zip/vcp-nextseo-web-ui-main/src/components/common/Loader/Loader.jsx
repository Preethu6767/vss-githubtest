import React from 'react'
import "./loader.scss"
const Loader = () => {
    return (
        <div className="loader-wrapper" style={{ overflow: "hidden" }}>
            <div className="edu-loader">
                <div className="pencil">
                    <div className="eraser"></div>
                    <div className="shaft"></div>
                    <div className="tip"></div>
                </div>
                <span className=' loader-text ' >Loading...</span>
            </div>
        </div>


    )
}

export default Loader