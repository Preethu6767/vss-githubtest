"use client"
import React, { useContext, useEffect, useState } from 'react'
import MyContext from "../../context/MyContext"
import { VcpEnrollmentUserGrid } from 'vcp-calendar-components';
import { genEnrollmentUserApi } from '../../services/calendar';
import { useParams } from 'next/navigation';

const EnrollmentGrid = () => {
    const [url, setUrl] = useState(null);
    const params = useParams();
    const { subscriberCode } = useContext(MyContext);
    useEffect(() => {
        const URL = genEnrollmentUserApi(subscriberCode, params.course_code, params.year);
        setUrl(URL)
    }, [subscriberCode, params.course_code])
    return (
        <VcpEnrollmentUserGrid url={url} studentsFlag={subscriberCode === "TA" ? true : false} />

    )
}

export default EnrollmentGrid