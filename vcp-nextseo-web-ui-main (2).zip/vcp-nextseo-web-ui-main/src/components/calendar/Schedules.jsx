"use client"
import React, { useContext, useEffect, useState } from 'react'
import { VcpSchedules } from 'vcp-calendar-components'
import { getInstructorsApi } from '../../services/contact'
import MyContext from '../../context/MyContext'
import { VcpInstructorProfile } from 'vcp-ui-components'
import { useRouter } from 'next/navigation'
import EnrollPopup from '../EnrollPopup'

const Schedules = ({ schedulesData }) => {
    const [instructors, setInstructors] = useState(null);
    const [instructor, setInstructor] = useState(null);
    const [selectedSchedules, setSelectedSchedules] = useState(null);
    const [filterFlag, setFilterFlag] = useState(false);
    const [profileFlag, setProfileFlag] = useState(false)
    const [enrollFlag, setEnrollFlag] = useState(false);
    const [selectedSchedule, setSelectedSchedule] = useState(null);
    const router = useRouter();
    const { subscriberCode } = useContext(MyContext);
    console.log(schedulesData, 'sd')
    const fetchInstructors = async () => {
        const res = await getInstructorsApi(subscriberCode)
        const json = await res.json();
        setInstructors(json.data)
    }
    const onClickCoachName = (data) => {
        const search = instructors?.find((e) => e.username === data.coachUserName)
        setInstructor(search);
        setProfileFlag(true)
    }
    const onClickEnrollBtn = (data) => {
        console.log(data)
        setEnrollFlag(true);
        setSelectedSchedule(data);
    }

    useEffect(() => {
        fetchInstructors();

    }, [subscriberCode])

    return (
        <>

            <VcpInstructorProfile
                flag={profileFlag}
                setFlag={setProfileFlag}
                instructorData={instructor} />

            <VcpSchedules
                onClickEnrollBtn={onClickEnrollBtn}
                onClickCoachName={onClickCoachName}
                data={filterFlag ? selectedSchedules : schedulesData}

            />

            <EnrollPopup flag={enrollFlag} setFlag={setEnrollFlag} courseCode={selectedSchedule?.courseCode} courseName={selectedSchedule?.scheduleTitle} />


        </>
    )
}

export default Schedules