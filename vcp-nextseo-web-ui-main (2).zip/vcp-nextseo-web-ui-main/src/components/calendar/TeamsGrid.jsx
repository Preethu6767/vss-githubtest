"use client"
import React, { useContext } from 'react'
import { VcpTeamsGrid } from 'vcp-calendar-components'
import { url as contactUrl } from '../../services/contact'
import { url as calendarUrl } from '../../services/calendar'
import MyContext from '../../context/MyContext'


const TeamsGrid = () => {
  const { subscriberCode } = useContext(MyContext)
  return (
    <VcpTeamsGrid subscriberCode={subscriberCode} contactUrl={contactUrl} calendarUrl={calendarUrl} />

  )
}

export default TeamsGrid