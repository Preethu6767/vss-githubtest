"use client"
import 'vcp-calendar-components/dist/dist/bundle.css';
import React, { useContext } from 'react'
import { VcpCalendar } from 'vcp-calendar-components'
import MyContext from '../../context/MyContext'
import { url as calendarUrl } from '../../services/calendar';
const CalendarSchendule = () => {
    const { subscriberCode } = useContext(MyContext);
    return (
        <VcpCalendar
            calendarUrl={calendarUrl}
            role={"web"}
            subscriberCode={subscriberCode}
            username={"null"}
            view={"AGENDA"
            }

        />
    )
}

export default CalendarSchendule
