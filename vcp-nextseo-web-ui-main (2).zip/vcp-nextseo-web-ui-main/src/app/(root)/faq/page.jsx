import React from 'react'
import { getPagesApi, getSubscriberCode } from '../../../services/elearning';
import Faq from '../../../components/ui/Faq';
import { headers } from 'next/headers';

const fetchData = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getPagesApi(subscriberCode, "faq")
  return await res.json();
}
const FaqPage = async () => {
  const faqData = await fetchData();
  let mainEntity = [];
  faqData?.data.forEach((item) => {
    let obj = {
      "@type": "Question",
      "name": item.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": item.answer
      }
    }
    mainEntity.push(obj);
  })
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity,
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <Faq faqData={faqData} />
    </>
  )
}

export default FaqPage