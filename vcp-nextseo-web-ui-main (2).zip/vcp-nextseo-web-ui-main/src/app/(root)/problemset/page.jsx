import React from 'react'
import Problemset from '../../../components/Problemset'

const ProblemSetPage = () => {
  return (
    <div><Problemset/></div>
  )
}

export default ProblemSetPage