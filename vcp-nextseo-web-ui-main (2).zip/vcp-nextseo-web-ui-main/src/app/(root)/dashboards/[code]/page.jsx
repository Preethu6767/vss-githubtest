import { getDashboardMenus, getSubscriberCode } from "../../../../services/elearning";
import { headers } from "next/headers";
import DashboardDetailsV2 from "../../../../components/ui/DashboardDetailsV2";

const fetchData = async (code) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getDashboardMenus(subscriberCode, code);
  return await res.json();

};

const DashboardPage = async ({ params }) => {
  const dashboardMenus = await fetchData(params.code);

  return (
    <DashboardDetailsV2 menus={dashboardMenus?.menus} />
  )
}

export default DashboardPage