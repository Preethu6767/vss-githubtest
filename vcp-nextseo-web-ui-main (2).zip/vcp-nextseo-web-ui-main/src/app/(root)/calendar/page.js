import React from "react";
import CalendarSchendule from "../../../components/calendar/CalendarSchendule";

const CalendarPage = () => {
  return <CalendarSchendule />;
};

export default CalendarPage;
