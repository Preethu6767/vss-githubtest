import React from 'react'
import { headers } from 'next/headers';
import { getSubscriberCode,getPagesApi } from '../../../services/elearning';
import News from '../../../components/ui/News';

const fetchNews = async () => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getPagesApi(subscriberCode,"news")
    return await res.json();
}
const NewsPage = async() => {
    const news=await fetchNews();
  return (
    <div className='mt-3'>
    <News news={news}/>
    </div>
  )
}

export default NewsPage