import React from 'react'
import { getPageHtmlApi, getSubscriberCode } from '../../../services/elearning';
import { headers } from 'next/headers';

const fetchData = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getPageHtmlApi(subscriberCode, "about");
  const json = await res.json();
  return json;
}

export async function generateMetadata() {
  const pageData = await fetchData();
  return {
    title: pageData.seo_title,
    description: pageData.seo_description,
    keywords: pageData.seo_keywords
  }
}
const AboutPage = async () => {
  let pageData = await fetchData();;

  return (
    <main>
      {

        pageData &&
        <div dangerouslySetInnerHTML={{ __html: pageData.html }} />
      }
    </main>
  )
}

export default AboutPage