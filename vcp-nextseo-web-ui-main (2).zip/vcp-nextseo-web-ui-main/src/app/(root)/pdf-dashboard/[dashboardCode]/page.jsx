import React from 'react'
import PDFDashboard from '../../../../components/ui/PDFDashboard'

const DashboardPage = ({ params }) => {
    return (
        <PDFDashboard dashboardCode={params?.dashboardCode} />
    )
}

export default DashboardPage