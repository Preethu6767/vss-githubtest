import React from 'react'
import { headers } from 'next/headers';
import { getSubscriberCode,getResultsApi } from '../../../../services/elearning';
import Result from '../../../../components/ui/Result';

const fetchResults = async (code) => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getResultsApi(subscriberCode,code)
    return await res.json();
}

const ResultPage = async({params}) => {
  const data=await fetchResults(params.code)

  return (
    <Result data={data}/>
  )
}

export default ResultPage