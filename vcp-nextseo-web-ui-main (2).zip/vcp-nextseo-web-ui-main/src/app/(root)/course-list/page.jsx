import React from 'react'
import CourseList from '../../../components/ui/CourseList'
import { headers } from 'next/headers';
import { getCoursesFromMariadbApi, getSubscriberCode } from '../../../services/elearning';

const fetchCourses = async () => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getCoursesFromMariadbApi(subscriberCode)
    return await res.json();
  }
const CourseListPage = async() => {
    const courses=await fetchCourses();
    return (
        <>
            <CourseList data={courses?.data} />
        </>
    )
}

export default CourseListPage