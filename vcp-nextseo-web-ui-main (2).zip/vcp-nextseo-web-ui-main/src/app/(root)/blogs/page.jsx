import React from 'react'
import { getSubscriberCode, getBlogsApi } from '../../../services/elearning';
import { headers } from 'next/headers';
import BlogList from '../../../components/BlogList';

const fetchData = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getBlogsApi(subscriberCode)
  return await res.json();
}
const BlogsPage = async () => {
  const blogs = await fetchData();
  return (
    <div>
      <BlogList blogs={blogs} />

    </div>
  )
}

export default BlogsPage