import React from 'react'
import { getSubscriberCode, getBlogApi } from '../../../../services/elearning';
import { headers } from 'next/headers';
const fetchData = async (code) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getBlogApi(subscriberCode, code)
  return await res.json();
}
const BlogPage = async ({ params }) => {
  const blog = await fetchData(params.code)
  const jsonLd =   {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": blog.title,
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <h3 className="fs-4 mb-3">{blog?.title}</h3>
      <div dangerouslySetInnerHTML={{ __html: blog?.description }} />
    </>
  )
}

export default BlogPage