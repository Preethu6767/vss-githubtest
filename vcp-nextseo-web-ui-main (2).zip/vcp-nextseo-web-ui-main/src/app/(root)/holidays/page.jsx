import React from 'react'
import { headers } from 'next/headers';
import { getSubscriberCode } from '../../../services/elearning';
import HolidaysUI from '../../../components/ui/HolidaysUI';
import { getSchedulesBySessionTypeApi } from '../../../services/calendar';

const fetchData = async () => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    try {
        const res = await getSchedulesBySessionTypeApi("holiday", subscriberCode)
        if (res?.ok) {
            return await res?.json();
        }
    }
    catch (e) {
        return [];
    }
}

const HolidaysPage = async () => {
    const data = await fetchData();
    return (
        <HolidaysUI data={data?.listOfSchedules} />
    )
}

export default HolidaysPage