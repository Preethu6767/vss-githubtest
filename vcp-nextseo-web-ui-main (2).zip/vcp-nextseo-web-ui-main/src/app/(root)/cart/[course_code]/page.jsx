import React from 'react'
import Cart from '../../../../components/Cart'
import { headers } from 'next/headers';
import { getSubscriberCode } from '../../../../services/elearning';
const CartPage = ({params}) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  return (
    <Cart courseCode={params.course_code} subscriberCode={subscriberCode}/>
  )
}

export default CartPage