
import { headers } from "next/headers";
import { getSubscriberCode, getPageHtmlApi } from "../../../../services/elearning"

const fetchData = async (code) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getPageHtmlApi(subscriberCode, code);
  const json = await res.json();
  return json;
}
export async function generateMetadata({params}) {
  const pageData = await fetchData(params.code);
  return {
    title: pageData.seo_title,
    description: pageData.seo_description,
    keywords: pageData.seo_keywords
  }
}

const HtmlPage = async ({params}) => {
  const pageData = await fetchData(params.code);

  return (
    <>
      {pageData && (
        <>
          <main>
            <div dangerouslySetInnerHTML={{ __html: pageData.html }} />
          </main>
        </>
      )}
    </>
  )
}

export default HtmlPage