import React from 'react'
import SchoolAdmissionsUI from '../../../components/ui/SchoolAdmissionsUI'

const SchoolAdmissionsPage = () => {
    return (
        <SchoolAdmissionsUI />
    )
}

export default SchoolAdmissionsPage