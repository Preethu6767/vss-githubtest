import CourseGroupFlyer from "../../components/ui/CourseGroupFlyer";
import { getPageHtmlApi, getSubscriberCode } from "../../services/elearning";
import { headers } from "next/headers";

const fetchData = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const homeRes = await getPageHtmlApi(subscriberCode, "home");
  return { pageData: await homeRes.json() };
};

export async function generateMetadata() {
  const { pageData } = await fetchData();
  return {
    title: pageData?.seo_title,
    description: pageData?.seo_description,
    keywords: pageData?.seo_keywords,
  };
}
export default async function Home() {
  let { pageData } = await fetchData();

  return (
    <>
      {pageData && (
        <main>
          <div dangerouslySetInnerHTML={{ __html: pageData?.html }} />
        </main>
      )}
      <CourseGroupFlyer />
    </>
  );
}
