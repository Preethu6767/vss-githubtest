import React from 'react'
import { headers } from 'next/headers';
import { getSubscriberCode, getJobsApi } from '../../../services/elearning';
import JobApplicationsUI from '../../../components/ui/JobApplicationsUI';

const fetchData = async () => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    try {
        const res = await getJobsApi(subscriberCode)
        if (res?.ok) {
            return await res?.json();
        }
    }
    catch (e) {
        return [];
    }
}

const JobsPage = async () => {
    const json = await fetchData();
    console.log(json)
    return (
        <JobApplicationsUI data={json?.data} />
    )
}


export default JobsPage