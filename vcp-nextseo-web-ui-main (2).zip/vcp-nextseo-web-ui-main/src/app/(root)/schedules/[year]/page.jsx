import React from 'react'
import { headers } from 'next/headers';
import { getAllSchedules, } from '../../../../services/calendar';

import Schedules from '../../../../components/calendar/Schedules';
import { getSubscriberCode } from '../../../../services/elearning';
import SchedulesMenu from '../../../../components/menus/SchedulesMenu';

const fetchData = async (year) => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getAllSchedules(subscriberCode, "null", year)

    return await res.json();
}
const SchedulePage = async ({ params }) => {
    const json = await fetchData(params.year);
    const { weekly, annual, tbd } = json?.listOfSchedule[0]
    let schedules = [...weekly, ...annual, ...tbd]
    
    return (
        <>
            <SchedulesMenu />
            <Schedules schedulesData={schedules} />
        </>
    )
}

export default SchedulePage