import React from 'react'
import { headers } from 'next/headers';
import { getAllSchedules, } from '../../../../../services/calendar';

import Schedules from '../../../../../components/calendar/Schedules';
import { getSubscriberCode } from '../../../../../services/elearning';
import SchedulesMenu from '../../../../../components/menus/SchedulesMenu';

const fetchData = async (year) => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getAllSchedules(subscriberCode, "null", year)

    return await res.json();
}
const AnnualPage = async ({ params }) => {
    const json = await fetchData(params.year);
    const { annual } = json?.listOfSchedule[0]
    let schedules = [...annual]
    return (
        <>
            <SchedulesMenu />
            <Schedules schedulesData={schedules} />
        </>
    )
}

export default AnnualPage