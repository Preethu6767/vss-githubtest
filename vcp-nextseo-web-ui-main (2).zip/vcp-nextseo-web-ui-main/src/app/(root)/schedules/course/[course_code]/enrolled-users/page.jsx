import React from 'react'
import EnrollmentGrid from '../../../../../../components/calendar/EnrollmentGrid'
import SchedulesMenu from '../../../../../../components/menus/SchedulesMenu'

const CourseEnrollmentUsers = ({params}) => {

    return (
        <>
        <SchedulesMenu courseFlag={true}/>
        <EnrollmentGrid  />
        </>
    )
}

export default CourseEnrollmentUsers