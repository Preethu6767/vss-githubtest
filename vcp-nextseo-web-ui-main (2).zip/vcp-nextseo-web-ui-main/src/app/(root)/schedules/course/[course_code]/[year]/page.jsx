import React from 'react'
import { headers } from 'next/headers';
import { getAllSchedules, } from '../../../../../../services/calendar';

import Schedules from '../../../../../../components/calendar/Schedules';
import { getSubscriberCode } from '../../../../../../services/elearning';
import SchedulesMenu from '../../../../../../components/menus/SchedulesMenu';

const fetchData = async (year,code) => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getAllSchedules(subscriberCode,"null",year,code)
    return await res.json();
}
const AnnualCourseSchedulePage = async ({params}) => {
    let schedules=[]
    try{

        const json = await fetchData(params.year,params.course_code);
        const {weekly,annual,tbd}=json?.listOfSchedule[0]
        schedules=[...weekly,...annual,...tbd]  
    }
    catch{

    }
      return (
        <>
        <SchedulesMenu courseFlag={true}/>
        <Schedules schedulesData={schedules} />
        </>
    )
}

export default AnnualCourseSchedulePage