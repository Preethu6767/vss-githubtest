import React from 'react'
import EnrollmentGrid from '../../../../components/calendar/EnrollmentGrid'
import SchedulesMenu from '../../../../components/menus/SchedulesMenu'

const EnrollmentUsers = () => {

    return (
        <>
        <SchedulesMenu/>
        <EnrollmentGrid />
        </>
    )
}

export default EnrollmentUsers