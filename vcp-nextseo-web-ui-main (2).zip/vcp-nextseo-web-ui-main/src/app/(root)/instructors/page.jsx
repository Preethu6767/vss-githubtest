import React from 'react'
import { headers } from 'next/headers';
import { getInstructorsApi } from '../../../services/contact';
import { getSubscriberCode } from '../../../services/elearning';
import InstructorsList from '../../../components/ui/InstructorsList';


const fetchData = async () => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getInstructorsApi(subscriberCode)
    return await res.json();
}
const InstructorsPage = async () => {
    const instructors = await fetchData();
    console.log(instructors)
    return (
        <InstructorsList instructors={instructors?.data} />
    )
}

export default InstructorsPage