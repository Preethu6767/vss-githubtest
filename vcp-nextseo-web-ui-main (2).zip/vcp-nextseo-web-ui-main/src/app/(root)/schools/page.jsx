import React from 'react'
import { headers } from 'next/headers';

import { getSchoolsApi } from '../../../services/contact';
import { getSubscriberCode, getLoginUrl } from '../../../services/elearning';
import SchoolsGrid from '../../../components/ui/SchoolsGrid';

const fetchData = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const loginUrl = getLoginUrl(headersList.get("host"))  
  const res = await getSchoolsApi(subscriberCode)
  return [await res.json(), `${loginUrl}/login`];
}
const SchoolsPage = async () => {
  const [schools, loginUrl] = await fetchData();
  return (
    <div><SchoolsGrid schools={schools?.data} loginUrl={loginUrl} /></div>
  )
}

export default SchoolsPage