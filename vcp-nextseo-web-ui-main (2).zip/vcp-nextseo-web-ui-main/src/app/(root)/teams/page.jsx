import React from 'react'
import TeamsGrid from '../../../components/calendar/TeamsGrid'

const TeamPage = () => {
  return (
<>
<TeamsGrid/>
</>  )
}

export default TeamPage