import React from 'react'
import CourseGroup from '../../../../components/CourseGroup';

const CourseGroupPage = async ({ params }) => {

    return (
        <CourseGroup courseGroupCode={params?.course_group_code} />
    )
}

export default CourseGroupPage