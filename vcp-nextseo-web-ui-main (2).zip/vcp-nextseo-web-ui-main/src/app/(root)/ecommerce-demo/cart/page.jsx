import React from "react";
import CartComponent from "../../../../components/ecommerce/CartComponent";

const Cart = () => {
  return <CartComponent />;
};
export default Cart;
