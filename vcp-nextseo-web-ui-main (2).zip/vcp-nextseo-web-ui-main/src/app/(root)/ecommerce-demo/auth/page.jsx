import React from "react";
import AuthComponent from "../../../../components/ecommerce/AuthComponent";

const Auth = () => {
  return <AuthComponent />;
};
export default Auth;
