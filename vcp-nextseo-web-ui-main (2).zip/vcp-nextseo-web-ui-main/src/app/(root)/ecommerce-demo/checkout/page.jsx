import React from "react";
import CheckoutComponent from "../../../../components/ecommerce/CheckoutComponent";

const Checkout = () => {
  return <CheckoutComponent />;
};
export default Checkout;
