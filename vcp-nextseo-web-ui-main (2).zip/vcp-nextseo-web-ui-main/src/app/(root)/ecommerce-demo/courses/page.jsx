import React from "react";
import CoursesComponent from "../../../../components/ecommerce/CoursesComponent";

const CoursesList = () => {
  return <CoursesComponent />;
};
export default CoursesList;
