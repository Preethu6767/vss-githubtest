import React from 'react'
import { getCoursePageApi, getSubscriberCode } from '../../../services/elearning';
import { headers } from 'next/headers';
import CoursePage from '../../../components/ui/CoursePage';

const fetchCourses = async () => {
  let data = [];
  try {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    const res = await getCoursePageApi(subscriberCode)
    const json = await res?.json();
    data = json?.data
  }
  catch (e) {
    console.log(e?.message)
  }
  return data;
}
const Page = async () => {
  const data = await fetchCourses();
  console.log(data)
  return (
    <>
      <CoursePage data={data} />
    </>
  )
}

export default Page