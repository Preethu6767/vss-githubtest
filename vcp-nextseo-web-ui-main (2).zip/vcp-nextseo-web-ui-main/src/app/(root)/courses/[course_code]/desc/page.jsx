import React from 'react'
import { headers } from 'next/headers';
import { getCourseApi, getSubscriberCode } from '../../../../../services/elearning';
import CourseDescription from '../../../../../components/ui/CourseDescription';

const fetchData = async (courseCode) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  let courseJson = {}
  try {
    const res = await getCourseApi(subscriberCode, courseCode);
    courseJson = await res.json();

  }
  catch (e) {
    console.log(e)
  }
  return courseJson?.data
}

export async function generateMetadata({ params }) {
  const course = await fetchData(params.course_code);
  console.log(course)
  return {
    title: course?.name,
    description: course?.description,
    keywords: course?.keyword
  };
}

const CourseDescriptionPage = async ({ params }) => {
  const course = await fetchData(params.course_code)
  console.log(course)
  return (
    <>
      {
        course &&
        <CourseDescription course={course} />
      }
    </>
  )
}

export default CourseDescriptionPage