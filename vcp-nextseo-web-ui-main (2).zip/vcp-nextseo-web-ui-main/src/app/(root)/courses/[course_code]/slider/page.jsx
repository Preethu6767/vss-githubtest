import React from 'react'
import { getCourseApi, getSliderApi, getSubscriberCode } from '../../../../../services/elearning';
import Slider from '../../../../../components/ui/Slider';
import { headers } from 'next/headers';

const fetchData = async (code) => {
    const headersList = headers();
    const subscriberCode = getSubscriberCode(headersList.get("host"));
    let data = null
    try {
        const courseRes = await getCourseApi(subscriberCode, code);
        const courseJson = await courseRes.json();
        if (courseJson?.data?.mongodb_course_code) {
            const res = await getSliderApi(subscriberCode, courseJson?.data?.mongodb_course_code)
            data = await res?.json();
        }
        return data
    }
    catch (e) {
        console.log(e?.message)
    }

}

const SliderPage = async ({ params }) => {
    const sliderData = await fetchData(params.course_code)

    return (
        <>
            {
                sliderData &&
                <Slider sliderData={sliderData} />
            }
        </>

    )
}

export default SliderPage