
import React from 'react'
import { headers } from 'next/headers';
import { getCourseApi, getCourseDetailsApi, getDashboardDetailsApi, getSubscriberCode } from '../../../../../services/elearning'
import DashboardDetails from '../../../../../components/ui/DashboardDetails';

const fetchData = async (courseCode) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  let dashboardsJson = [];
  try {
    const courseRes = await getCourseApi(subscriberCode, courseCode);
    const courseJson = await courseRes.json();

    if (courseJson?.data?.mongodb_course_code) {
      const res = await getDashboardDetailsApi(subscriberCode, courseJson?.data?.mongodb_course_code);
      dashboardsJson = await res.json();
    }

  }
  catch (e) {
    console.log(e?.message)
  }
  return {
    dashboards: dashboardsJson ?? []
  }
}


const CourseTOCPage = async ({ params }) => {
  const { dashboards } = await fetchData(params.course_code);

  return (
    <>
      {
        dashboards?.length > 0 &&
        <DashboardDetails dashboards={dashboards} />
      }
    </>
  )
}

export default CourseTOCPage