import React from "react";
import SubNav from "../../../../components/menus/SubNav";

const CoursePageLayout = ({ children }) => {
  return (
    <>
      <div className="mb-2">
        <SubNav />
      </div>
      <div className="mb-3 p-2">{children}</div>
    </>
  );
};

export default CoursePageLayout;
