
import React from 'react'
import { headers } from 'next/headers';
import { getCourseApi, getCourseDetailsApi, getSubscriberCode } from '../../../../services/elearning'
import CourseDetailsDashboardUI from '../../../../components/ui/CourseDetailsDashboardUI';

const fetchData = async (courseCode) => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  let dashboardsJson = {};
  let courseJson = {}
  try {
    const res = await getCourseDetailsApi(courseCode);
    const res2 = await getCourseApi(subscriberCode, courseCode);
    dashboardsJson = await res.json();
    courseJson = await res2.json();
  }
  catch (e) {
    console.log(e?.message)

  }
  return {
    dashboards: dashboardsJson?.data ?? {
    }, course: courseJson?.data ?? {}
  }
}

export async function generateMetadata({ params }) {
  const { course } = await fetchData(params.course_code);
  return {
    title: course?.name,
    description: course?.description,
    keywords: course?.keyword
  };
}

const CourseTOCPage = async ({ params }) => {
  const { dashboards, course } = await fetchData(params.course_code);

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Course',
    name: course?.name,
    description: course?.description
  }
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <CourseDetailsDashboardUI data={dashboards} />
    </>
  )
}

export default CourseTOCPage