import React from 'react'
import CourseGroupFlyer from '../../../../components/ui/CourseGroupFlyer'

const FlyerNewPage = () => {
  return (
 <>
 <CourseGroupFlyer/>
 </>  )
}

export default FlyerNewPage