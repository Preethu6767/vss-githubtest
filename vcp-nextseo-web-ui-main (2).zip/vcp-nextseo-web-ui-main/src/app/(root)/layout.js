import React from "react";
import Wrapper from "../../components/Wrapper";
import "../globals.scss";
import {
  getConfigFile,
  getCourseGroupApi,
  getMenuApi,
  getPagesApi,
  getSubscriberCode,
} from "../../services/elearning";
import { headers } from "next/headers";

const fetchData = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const topMenuRes = await getMenuApi(subscriberCode, "topmenu");
  const leftMenuRes = await getMenuApi(subscriberCode, "leftmenu");
  const footerRes = await getMenuApi(subscriberCode, "footer");
  const newsRes = await getPagesApi(subscriberCode, "news");
  const configRes = await getConfigFile(subscriberCode, "site-config");
  const courseGroupsRes = await getCourseGroupApi(subscriberCode);

  return {
    newsData: await newsRes.json(),
    topMenuData: await topMenuRes.json(),
    leftMenuData: await leftMenuRes.json(),
    footerData: await footerRes.json(),
    configData: await configRes.json(),
    courseGroupsData: await courseGroupsRes.json(),
  };
};
const layout = async ({ children }) => {
  const {
    topMenuData,
    leftMenuData,
    footerData,
    newsData,
    configData,
    courseGroupsData,
  } = await fetchData();

  return (
    <>
      <Wrapper
        topMenuData={topMenuData}
        leftMenuData={leftMenuData}
        footerData={footerData}
        newsData={newsData}
        configData={configData}
        courseGroupsData={courseGroupsData?.data}
      >
        {children}
      </Wrapper>
    </>
  );
};

export default layout;
