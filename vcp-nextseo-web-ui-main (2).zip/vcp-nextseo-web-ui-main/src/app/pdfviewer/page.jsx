import React from 'react'

import HtmlPdfViewer from '../../components/HtmlPdfViewer'
const page = () => {
    return (
        <HtmlPdfViewer />
    )
}

export default page