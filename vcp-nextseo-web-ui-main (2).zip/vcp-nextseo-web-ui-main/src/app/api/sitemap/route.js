import { NextResponse } from "next/server";
let lastmod = "2024-12-18";
const routes = ["", "about", "courses", "schedules/2024", "calendar", "news"];

export async function GET(req) {
  const hostname = req.headers.get("host");
  const baseUrl = `https://${hostname}/`;

  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
  <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${routes
    .map(
      (route) => `
  <url>
    <loc>${baseUrl}${route}</loc>
    <lastmod>${lastmod}</lastmod>
  </url>`
    )
    .join("")}
</urlset>`;

  // Return the XML response with correct Content-Type
  return new NextResponse(sitemapXml, {
    headers: {
      "Content-Type": "application/xml",
    },
    status: 200,
  });
}
