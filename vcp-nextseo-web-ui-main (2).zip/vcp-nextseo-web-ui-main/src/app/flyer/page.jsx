"use client"
import React, { useContext } from 'react'
import { VcpTaFlyer, VcpVilFlyer } from 'vcp-ui-components';
import MyContext from '../../context/MyContext';

const page = () => {
 const {subscriberCode}=useContext(MyContext);
  return (
    <>
      {
        subscriberCode === "TA" && <VcpTaFlyer />
      }
      {
        subscriberCode === "VIL" && <VcpVilFlyer />
      }
    </>
  )
}

export default page