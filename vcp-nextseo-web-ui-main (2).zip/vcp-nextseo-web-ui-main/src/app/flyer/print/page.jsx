"use client"
import React, { useContext } from 'react'
import { VcpTaFlyerPrint } from 'vcp-ui-components';
import MyContext from '../../../context/MyContext';

const PrintFlyerPage = () => {
const {subscriberCode}=useContext(MyContext)
    return (
        <>
        {
            subscriberCode==="TA" &&
        <VcpTaFlyerPrint />
        }
        </>
    )
}

export default PrintFlyerPage