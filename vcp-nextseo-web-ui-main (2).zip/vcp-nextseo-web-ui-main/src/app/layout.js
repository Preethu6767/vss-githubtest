import { MyContextProvider } from "../context/MyContext";
import CssWrapper from "../components/CssWrapper";
import { getConfigFile, getSubscriberCode } from "../services/elearning";
import { headers } from "next/headers";
import Script from "next/script";
import { GoogleOAuthProvider } from "@react-oauth/google";
import { Toaster } from "react-hot-toast";

const fetchConfigFile = async () => {
  const headersList = headers();
  const subscriberCode = getSubscriberCode(headersList.get("host"));
  const res = await getConfigFile(subscriberCode, "site-config");
  return await res.json();
};

export async function generateMetadata() {
  const config = await fetchConfigFile();
  return {
    title: config?.title,
    description: config?.description,
    keywords: config?.keywords,
  };
}

export default async function MainLayout({ children }) {
  const config = await fetchConfigFile();
  return (
    <html lang="en">
      <body className="bg-white">
        <MyContextProvider>
          <GoogleOAuthProvider clientId="952587809209-6dm3ldkb1qmj229gr02lr7r6gig96esp.apps.googleusercontent.com">
            <Toaster />
            <CssWrapper>{children}</CssWrapper>
          </GoogleOAuthProvider>
        </MyContextProvider>
        <Script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(config?.organization_schema),
          }}
        />
      </body>

      <Script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" />
    </html>
  );
}
