"use client"
import { userLoginApi } from "../services/contact";
import { getSubscriberCode } from "../services/elearning";
const { createContext, useState, useEffect } = require("react");
const MyContext = createContext();

let frontendUrl;
const MyContextProvider = (props) => {
    const [user, setUser] = useState(null);
    const [subscriberCode, setSubscriberCode] = useState(null);
    const [bufferCourseCode, setBufferCourseCode] = useState(null);
    const [courseGroups, setCourseGroups] = useState(null);

    const getLoggedIn = async () => {
        let providerToken = localStorage.getItem("jwtToken");
        if (!providerToken) return;
        let payload = {
            token: providerToken,
        }
        const res = await userLoginApi(payload)
        const data = await res.json();
        if (res.ok) {
            setUser({
                name: data.full_name,
                access_token: providerToken,
                username: data.username,
                img_url: data.profile_url,
                email: data.email
            });
        }
    };

    const getLoggedOut = () => {
        localStorage.removeItem("jwtToken");
        setUser(null)
    }
    useEffect(() => {
        frontendUrl = `${window.location.protocol}//${window.location.host}`;
        const subs = getSubscriberCode(window.location.host);

        setSubscriberCode(subs);
        getLoggedIn();
    }, []);

    return (
        <MyContext.Provider
            value={{ user, setUser, frontendUrl, subscriberCode, bufferCourseCode, setBufferCourseCode, getLoggedIn, getLoggedOut, setCourseGroups, courseGroups }}
        >
            {props.children}
        </MyContext.Provider>
    );
};

export { MyContextProvider };
export default MyContext;
